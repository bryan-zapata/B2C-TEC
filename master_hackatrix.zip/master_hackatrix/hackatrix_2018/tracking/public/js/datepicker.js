  $(document).ready(function(){



	var fecha = $.datepicker.formatDate('yy-mm-dd', new Date());

    	$("#dt_desde").datepicker({
       		dateformat:"yy-mm-dd"
    	}).val(fecha);

	 $("#dt_hasta").datepicker({
	       dateformat:"yy-mm-dd"
	    }).val(fecha);

});

