$(document).ready(function(){
    $("#navbar-icon-menu").click(function(){
       //$(".main_sidebar").toggle();
        $('.main-nav').add($('body')).toggleClass('mostrar');

    });
});
