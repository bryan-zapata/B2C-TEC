<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracking extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->layout->setLayout("template");
		$this->load->model("Model_tracking","tracking");
		
	}

	public function index()
	{
             
        $this->layout->view('index');
	}

	public function resultados($id=null)
	{
		$tracknumber = $this->input->post("txttrack");

		$datos = $this->tracking->getDatosEnvio($tracknumber);
		
		

		$this->layout->view('resultados',compact("datos"));
	
	
		//echo $tracknumber;

		//$this->layout->view('resultados');
	}
}
