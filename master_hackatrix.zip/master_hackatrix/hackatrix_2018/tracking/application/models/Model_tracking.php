<?php
class Model_tracking extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}


	public function getDatosEnvio($tracknumber)
	{


				
		$sql = " SELECT * FROM envios env 
		inner JOIN productos prd on prd.id_producto = env.id_producto
		inner JOIN usuarios usr on usr.id_usuario = env.id_usuario
		inner JOIN proveedores prv on prv.id_proveedor = env.id_proveedor
		inner JOIN sensores sen on sen.id_sensor = env.id_sensor
		where env.id_envio = ".$tracknumber." and env.estado_envio = 1";

		$query = $this->db->query($sql);

	

		if($query->result())
		{
			
			$data = $query->result();	
			
			foreach ($data as $key => $value) 
			{
				echo $key;
				$data[$key]->movimientos = $this->getMovimientos($value->id_envio);
			}
			return $data;
			
		}else{
			return false;
		}
		


	}

	public function getMovimientos($id_envio)
	{


				
		$sql = " SELECT * FROM movimientos mov 
		
		where mov.id_envio = ".$id_envio;

		$query = $this->db->query($sql);

		if($query->result())
		{
			
			
			
			
			return $query->result();
		}else{
			return false;
		}



	}

	

}
