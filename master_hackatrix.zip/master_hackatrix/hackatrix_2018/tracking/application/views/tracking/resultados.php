<?php

    foreach($datos as $dato)
    {
        $usuario = $dato->nom_usuario;
        $dire_usr = $dato->direccion_usuario;
        $fono_usr = $dato->fono_usuario;
        $proveedor = $dato->nom_proveedor;
        $dire_prv = $dato->direccion_proveedor;
        $fono_prv = $dato->fono_proveedor;
        $producto = $dato->nom_producto;
        $desc_envio = $dato->desc_envio;
        $cantidad_envio = $dato->cantidad_envio;
        $unidad_envio = $dato->unidad_envio;
        $estado_envio = $dato->estado_envio;
        $movimientos = $dato->movimientos;
    }
?> 



<div class="container">

<div class="card text-center">
  <div class="card-header">
    RESULTADOS DE LA BUSQUEDA
  </div>
  <div class="card-body">
    <p class="card-text">
        <div class="row">

        <div class="col-lg-12">

<div class="row">
    <div class="col-lg-12 mb-2">Datos del Producto Enviado</div>
    <br/>
    <div class="col-lg-12">

        <table class="table">
        
        <tbody>                        
            <tr>
                <th scope="row">Producto</th>
                <td><?php echo $producto; ?> </td>                            
            </tr>
            <tr>
                <th scope="row">Descripción</th>
                <td><?php echo $desc_envio; ?> </td>                            
            </tr>
            <tr>
                <th scope="row">Cantidad</th>
                <td><?php echo $cantidad_envio; ?> </td>                            
            </tr>
            <tr>
                <th scope="row">Unidad de Medida</th>
                <td><?php echo $unidad_envio; ?> </td>                            
            </tr>
            <tr>
                <th scope="row">Estado del Envio</th>
                <td><?php 
                
                    switch ($estado_envio) {
                        case 1:
                            $estado="En Proceso";
                            break;
                        case 2:
                                $estado="En demora";
                            break;
                        case 3:
                            $estado="Cerrado";
                            break;
                        
                        
                    }
                
                
                    echo $estado; ?> </td>                            
            </tr>
        
        </tbody>
        </table>
    </div>

</div>
</div>
            <div class="col-lg-6">

                <div class="row">
                    <div class="col-lg-12 mb-2">Datos del Origen</div>
                    <br/>
                    <div class="col-lg-12">

                        <table class="table">
                        
                        <tbody>                        
                            <tr>
                                <th scope="row">Usuario</th>
                                <td><?php echo $usuario; ?> </td>                            
                            </tr>
                            <tr>
                                <th scope="row">Dirección</th>
                                <td><?php echo $dire_usr; ?> </td>                            
                            </tr>
                            <tr>
                                <th scope="row">Telefono</th>
                                <td><?php echo $fono_usr; ?> </td>                            
                            </tr>
                           
                        </tbody>
                        </table>
                    </div>
                
                </div>
            </div>
            <div class="col-lg-6">
            <div class="row">
            <div class="col-lg-12 mb-2">Datos del Destino</div>
                    <br/>
                    <div class="col-lg-12">

                        <table class="table">
                        
                        <tbody>                        
                            <tr>
                                <th scope="row">Destino</th>
                                <td><?php echo $proveedor; ?> </td>                            
                            </tr>
                            <tr>
                                <th scope="row">Dirección</th>
                                <td><?php echo $dire_prv; ?> </td>                            
                            </tr>
                            <tr>
                                <th scope="row">Telefono</th>
                                <td><?php echo $fono_prv; ?> </td>                            
                            </tr>
                           
                        </tbody>
                        </table>
                    </div>
            </div>
            </div>
            <br/>

             <div class="col-lg-12">
            <div class="row">
            <div class="col-lg-12 mb-2">Movimientos</div>
                    <br/>
                    <div class="col-lg-12">

                        <table class="table">
                        <thead class="thead-dark">
                            <tr>
                            <th scope="col">#</th>
                            <th scope="col">Temperatura</th>
                            <th scope="col">Latitud</th>
                            <th scope="col">Longitud</th>
                            <th scope="col">Fecha</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php
                            foreach ($movimientos as $movi) 
                            {
                                
                            
                        ?>
                            <tr>
                            <th scope="row">1</th>
                            <td><?php echo $movi->temperatura;  ?></td>
                            <td><?php echo $movi->latitud;  ?></td>
                            <td><?php echo $movi->longitud;  ?></td>
                            <td><?php echo $movi->fecha;  ?></td>
                            </tr>
                        <?php

                            }
                        ?>  
                        </tbody>
                        </table>

                        
                    </div>
            </div>
            </div>
            
        
        
        
        </div>
    
    </p>
    
  </div>
  <div class="card-footer text-muted">
    Tracking de Envios - <?php echo date("Y"); ?>
  </div>
</div>



</div>

