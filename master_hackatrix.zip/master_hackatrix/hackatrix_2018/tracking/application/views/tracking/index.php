<div class="container">

    <div class="caja"> 
        <div class="titulo">Tracking de Envios</div>
    
    <?php echo form_open(base_url()."resultados",array("role"=>"form","class"=>"form-horizontal txttracknumber")); ?>
    <div class="form-group">
        
        <input type="text" class="form-control" id="txttrack" name="txttrack" placeholder="Ingrese el track number">
        
    </div>
    
    <button type="submit" class="btn btn-primary">Buscar</button>
    </form>

    </div>

</div>

