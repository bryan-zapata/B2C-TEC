<!DOCTYPE html>
<html lang="es">
<head>
	<title><?php echo $this->layout->getTitle()?></title>
	<meta charset="UTF-8" />
	<meta name="description" content="<?php echo $this->layout->getDescripcion()?>" />
  	<meta name="keywords" content="<?php echo $this->layout->getKeywords()?>" />
  	<script src="<?php echo base_url()."public/js/jquery-3.2.0.min.js"?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()."public/bootstrap/css/bootstrap.min.css"?>">
	<script src="<?php echo base_url()."public/bootstrap/js/bootstrap.min.js"?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()."public/css/estilo.css"?>">

</head>


<body>


<?php echo $content_for_layout;?>


</body>
</html>
